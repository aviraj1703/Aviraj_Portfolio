import requests
import json
import pandas as pd
from io import BytesIO


def get_excel_data(excel_data, site_id, feature_release_notes, headers):
    # Use the token to access SharePoint file
    file_url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root:/{feature_release_notes}"
    file_r = requests.get(file_url, headers=headers)

    # Extract the download URL from the response
    download_url = file_r.json().get("@microsoft.graph.downloadUrl")

    # Stream the file using the download URL
    response = requests.get(download_url, stream=True)
    response.raise_for_status()

    # Load the Excel file from the response stream into a BytesIO object
    excel_data = BytesIO(response.content)
    return excel_data


# Function to read column B data from a sheet, skipping the first two rows and stopping at NaN
def get_column_b_data(excel_data, sheet_name):
    try:
        df = pd.read_excel(
            excel_data,
            sheet_name=sheet_name,
            engine="openpyxl",
            skiprows=2,
            usecols=[1],
        )
        column_b_data = df.iloc[:, 0].dropna().tolist()
    except ValueError:
        print(f"Worksheet named '{sheet_name}' not found. Adding empty data.")
        column_b_data = []
    return column_b_data


# Load the configuration
with open("config.json") as f:
    config = json.load(f)
    tenant_id = config["TENANT_ID"]
    client_id = config["CLIENT_ID"]
    client_secret = config["CLIENT_SECRET"]
    site_url = config["SITE_URL"]

with open("release_notes_url.json") as f:
    release_notes_url = json.load(f)
    feature_release_notes_1 = release_notes_url["release_notes1_path"]
    feature_release_notes_2 = release_notes_url["release_notes2_path"]
    feature_release_notes_3 = release_notes_url["release_notes3_path"]
    feature_release_notes_1_url = release_notes_url["release_notes1_url"]
    feature_release_notes_2_url = release_notes_url["release_notes2_url"]
    feature_release_notes_3_url = release_notes_url["release_notes3_url"]


# Get AAD token
token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"
token_data = {
    "grant_type": "client_credentials",
    "client_id": client_id,
    "client_secret": client_secret,
    "resource": "https://graph.microsoft.com",
}
token_r = requests.post(token_url, data=token_data)
token = token_r.json().get("access_token")

# Use the token to get the site ID
headers = {"Authorization": "Bearer " + token}
site_r = requests.get(site_url, headers=headers)
site_id = site_r.json().get("id")

# Get Excel data for each feature release note
excel_data_1 = get_excel_data(BytesIO(), site_id, feature_release_notes_1, headers)
excel_data_2 = get_excel_data(BytesIO(), site_id, feature_release_notes_2, headers)
excel_data_3 = get_excel_data(BytesIO(), site_id, feature_release_notes_3, headers)

# Read data from the specified sheets
sheets = ["PAAS", "TF", "CDUI", "Grammar"]
data = {
    "url": {
        "f1": feature_release_notes_1_url,
        "f2": feature_release_notes_2_url,
        "f3": feature_release_notes_3_url,
        "r1": feature_release_notes_1,
        "r2": feature_release_notes_2,
        "r3": feature_release_notes_3,
    },
    "Feature_Release_Notes_1": {},
    "Feature_Release_Notes_2": {},
    "Feature_Release_Notes_3": {},
}

for sheet in sheets:
    data["Feature_Release_Notes_1"][sheet] = get_column_b_data(excel_data_1, sheet)
    data["Feature_Release_Notes_2"][sheet] = get_column_b_data(excel_data_2, sheet)
    data["Feature_Release_Notes_3"][sheet] = get_column_b_data(excel_data_3, sheet)

# Save the data to a JSON file
json_file_path = "feature_release_nfbs.json"
with open(json_file_path, "w") as json_file:
    json.dump(data, json_file, indent=4)

print(f"Column B data saved to {json_file_path}")
