import json
import sys


def load_json_file(file_path):
    try:
        with open(file_path, "r") as json_file:
            return json.load(json_file)
    except FileNotFoundError:
        print(f"Error: JSON file not found at {file_path}")
        sys.exit(1)
    except json.JSONDecodeError:
        print("Error: JSON file is not a valid JSON")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {str(e)}")
        sys.exit(1)


def check_id_in_json(json_data, outer_key, inner_key, nfb_id):
    if outer_key in json_data and inner_key in json_data[outer_key]:
        if nfb_id in json_data[outer_key][inner_key]:
            return True
    return False


def print_error_and_info(nfb_id, URLs):
    header_color="\033[93m"
    info_color = "\033[94m"
    reset_color = "\033[0m"

    header = (
        f"{header_color}URLs for particular 'RELEASE NOTES' are as below:{reset_color}"
    )
    info_message_1 = (
        f"{info_color}URL:{reset_color} {URLs["f1"]}\n"
        f"{info_color}Sharepoint path:{reset_color} {URLs["r1"]}\n"
    )
    info_message_2 = (
        f"{info_color}URL:{reset_color} {URLs["f2"]}\n"
        f"{info_color}Sharepoint path:{reset_color} {URLs["r2"]}\n"
    )
    info_message_3 = (
        f"{info_color}URL:{reset_color} {URLs["f3"]}\n"
        f"{info_color}Sharepoint path:{reset_color} {URLs["r3"]}\n"
    )

    print(header)
    print(info_message_1)
    print(info_message_2)
    print(info_message_3)


def main():
    if len(sys.argv) != 3:
        print("Usage: python verify_nfb.py <component> <nfb_id>")
        sys.exit(1)

    json_file_path = "feature_release_nfbs.json"
    env_master = "feature_release_notes_1"
    env_qa3 = "feature_release_notes_2"
    env_hotfix = "feature_release_notes_3"
    component = sys.argv[1]
    nfb_id = sys.argv[2]

    json_data = load_json_file(json_file_path)

    if check_id_in_json(json_data, env_master, component, nfb_id):
        sys.exit(0)
    if check_id_in_json(json_data, env_qa3, component, nfb_id):
        sys.exit(0)
    if check_id_in_json(json_data, env_hotfix, component, nfb_id):
        sys.exit(0)

    print_error_and_info(nfb_id, json_data["url"])
    sys.exit(1)


if __name__ == "__main__":
    main()
