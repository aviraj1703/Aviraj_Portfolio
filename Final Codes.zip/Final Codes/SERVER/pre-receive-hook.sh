#!/bin/bash

# Policy Flags
hook_enable_flag="yes"
branch_policy_flag="yes"
unit_test_policy_flag="yes"

# Variables
component="PAAS"
success_rate_required=100

# Disable Hook
if [[ $hook_enable_flag = "no" ]]; then
    exit 0
fi

# Allowed all operations done through JENKINS
if [[ $GL_USERNAME = "jenkins" ]]; then
    echo "Operations through pipeline, aborting pre-receive hook..."
    exit 0
fi

# Case Insensitive
shopt -s nocasematch

# Function to verify NFB ID in the CSV content
verifyNFB() {
    local TARGET_BRANCH_NAME="$1"

    # Extract ID from branch name
    local prefix=$(echo "$TARGET_BRANCH_NAME" | awk -F '-' '{print $1}')
    local id=$(echo "$TARGET_BRANCH_NAME" | awk -F '-' '{print $2}')
    local nfb_id="${prefix}-${id}"

    # File path of python code to validate nfbs
    python3 /var/opt/gitlab/git-data/repositories/verify_nfb.py "$component" "$nfb_id"
    exit_code=$?

    if [ $exit_code -eq 0 ]; then
        echo -e "\e[92mINFO: ID '$nfb_id' found in RELEASE notes!\e[0m\n"
    else
        echo -e "\e[91m------------------------------------------------------\e[0m"
        echo -e "\e[91mERROR: '$nfb_id' not found in RELEASE MANAGEMENT notes!\e[0m"
        echo -e "\e[91m------------------------------------------------------\e[0m"
        echo -e "\e[92mINFO: Please contact 'RELEASE MANAGEMENT' team to get update the 'RELEASE NOTES'.\e[0m"
        echo -e "\e[92mINFO: '$TARGET_BRANCH_NAME' will not be merged until you get [$nfb_id] updated in 'RELEASE NOTES'.\e[0m\n"
        exit 1
    fi
}

# Fetch GIT Details
while read oldrev newrev refname; do
    # Get the parent commit array
    parent_commits=($(git rev-list --parents -n 1 $newrev))

    # Get the commit message
    commit_message=$(git log --format=%B -n 1 $newrev)

    # Check for merge or revert or push event
    if [ "${#parent_commits[@]}" -gt 2 ]; then
        regex="Merge branch '([a-zA-Z0-9_-]+)' into '"

        if [[ $commit_message =~ $regex ]]; then
            source_branch_name="${BASH_REMATCH[1]}"
            echo "Branch name: $source_branch_name"
        else
            echo "Branch name not found: $source_branch_name"
            exit 1
        fi

        if [[ $source_branch_name == experiment* ]]; then
            echo -e "\n\e[91mERROR: Experiment branches are not allowed to be merged.\e[0m\n"
            exit 1
        fi
    elif [[ $commit_message == "Revert "* ]]; then
        echo "Revert event is triggered, aborting pre-receive hook..."
        exit 0
    else
        target_branch_name=$(basename "$refname")            # Branch name
        commit_id_full=$(git rev-list --max-count=1 $newrev) # Commit hash
        commit_id=$(git rev-parse --short=7 $commit_id_full) # Short commit hash
    fi
done

# Allow revert operation
if [[ $target_branch_name =~ ^(revert)+-.*$ ]]; then
    echo "Revert event is triggered, aborting pre-receive hook..."
    exit 0
fi

# Block push to master
if [[ $target_branch_name = "master" ]]; then
    echo -e "\n\e[91m------------------------------------------------------\e[0m"
    echo -e "\e[91mERROR: You are not allowed to push directly to master.\e[0m"
    echo -e "\e[91m------------------------------------------------------\e[0m\n"
    exit 1
fi

# Validate Branch Name
if [ $branch_policy_flag = "yes" ]; then
    if [[ $target_branch_name =~ ^(experiment)+-.*$ ]]; then
        echo -e "\n\e[92mINFO: User will not be merging changes [current branch - $target_branch_name] to master or any other release branch, hence you can proceed further with the current branch.\e[0m\n"
        if curl -s -I -X HEAD "https://${S3_BUCKET}.s3.amazonaws.com/${FILE_KEY}" | grep -q "HTTP/1.1 200 OK"; then
            curl -X DELETE "https://${S3_BUCKET}.s3.amazonaws.com/${FILE_KEY}" >/dev/null 2>&1
        fi
        exit 0
    elif [[ $target_branch_name =~ ^(BUG|NFB)-[0-9]+-(feature|bugfix|improvement|library|hotfix|prodfix|release|task)-.*$ ]]; then
        echo -e "\n\e[92mINFO: Your branch name is approved as you have followed the policy.\e[0m\n"
    else
        echo -e "\n\e[91m----------------------------------------------------------------------------------\e[0m"
        echo -e "\e[91mERROR: Your commit was rejected as you have not followed the branch naming policy.\e[0m"
        echo -e "\e[91mERROR: Please fix your branch name or contact your repository admin.\e[0m"
        echo -e "\e[91m----------------------------------------------------------------------------------\e[0m\n"
        echo -e "\e[92mINFO: If the user will not merge changes to master or any other release branch, then create a branch with 'experiment' followed by other names, e.g., experiment-redisfix.\e[0m"
        echo -e "\e[92mINFO: If the user will merge changes to master or any other release branch, then create a branch with 'BUG|NFB-feature|bugfix|improvement|library|hotfix|prodfix|release|task' followed by other names.\e[0m"
        echo -e "\e[92mINFO: Branch names must adhere to the policy as per the blog\e[0m"
        echo -e "\e[92mINFO: Example: BUG-123-bugfix-multi-tenant or NFB-123-feature-multi-tenant or BUG-123-improvement|library-multi-tenant.\e[0m"
        echo -e "\e[92mINFO: User should rename the branch as per policy and try again.\e[0m\n"
        exit 1
    fi
else
    echo -e "\n\e[92mINFO: User will not be merging changes [branch - $target_branch_name] to master or any other release branch, hence the user can proceed further.\e[0m\n"
fi

# Required Variables for s3 access
S3_BUCKET="git-hook"                               # Bucket name
FILE_KEY="${target_branch_name}_${commit_id}.html" # Report file name

# Unit Test Report Validation
if [ $unit_test_policy_flag = "yes" ]; then
    # Check for existance of file
    if curl -s -I -X HEAD "https://${S3_BUCKET}.s3.amazonaws.com/${FILE_KEY}" | grep -q "HTTP/1.1 200 OK"; then
        # Store whole content in variable
        file_content=$(curl -s "https://${S3_BUCKET}.s3.amazonaws.com/${FILE_KEY}")

        # We will just valiade summary table
        summary_section=$(echo "$file_content" | grep -Pzo "(?s)<h2><a name=\"Summary\"><\/a>Summary<\/h2>.*?<\/table>" | tr -d '\000')

        # Check for summary table and matching of dates
        if [ -n "$summary_section" ]; then
            # Fetch all necessary details
            errors=$(echo "$summary_section" | grep -oP '<td[^>]*>\K[0-9]+' | sed -n '2p')
            failures=$(echo "$summary_section" | grep -oP '<td[^>]*>\K[0-9]+' | sed -n '3p')
            success_rate=$(echo "$summary_section" | grep -oP '<td[^>]*>\K[0-9.]+%?' | sed -n '5p')

            # Unit Test Report Data
            echo -e "\e[93mUnit Test Report description:\e[0m"
            echo -e "\e[94mErrors:\e[0m "$errors
            echo -e "\e[94mFailures:\e[0m "$failures
            echo -e "\e[94mRate of success:\e[0m "$success_rate

            # Get the floor value of success_rate
            success_rate_achieved=$(echo "$success_rate" | awk '{print int($1)}')

            # Validate report details and delete report accordingly
            if [ "$success_rate_achieved" -lt "$success_rate_required" ]; then
                echo -e "\n\e[91m------------------------------------------------------------------------------\e[0m"
                echo -e "\e[91mERROR: Your commit was rejected as you have not followed the Test Pass policy.\e[0m"
                echo -e "\e[91m------------------------------------------------------------------------------\e[0m\n"
                echo -e "\e[92mINFO: If the user is getting any errors in the test run, then fix the error, e.g., Errors: 0\e[0m"
                echo -e "\e[92mINFO: If the user is getting any failures while running tests, then fix the failures\e[0m"
                echo -e "\e[92mINFO: If the user is getting a success rate less than 100%, then achieve a success rate equal to 100%\e[0m\n"
                curl -X DELETE "https://${S3_BUCKET}.s3.amazonaws.com/${FILE_KEY}" >/dev/null 2>&1
                exit 1
            else
                echo -e "\n\e[92mINFO: Your commit is approved as you have followed the Test Pass policy\e[0m\n"
                if [[ $target_branch_name == NFB* ]]; then
                    verifyNFB "$target_branch_name"
                else
                    exit 0
                fi
                curl -X DELETE "https://${S3_BUCKET}.s3.amazonaws.com/${FILE_KEY}" >/dev/null 2>&1
            fi
        else
            echo -e "\n\e[91m--------------------------------------------------\e[0m"
            echo -e "\e[91mERROR: There is no description in Unit Test Report.\e[0m"
            echo -e "\e[91m--------------------------------------------------\e[0m"
            echo -e "\e[92mINFO: Please generate Unit Test Report again and try to push.\e[0m\n"
            curl -X DELETE "https://${S3_BUCKET}.s3.amazonaws.com/${FILE_KEY}" >/dev/null 2>&1
            exit 1
        fi
    else
        echo -e "\n\e[91m-----------------------------------------\e[0m"
        echo -e "\e[91mERROR: Unit Test Report is not generated.\e[0m"
        echo -e "\e[91m-----------------------------------------\e[0m"
        echo -e "\e[92mINFO: Generate the report file to proceed.\e[0m"
        echo -e "\e[92mINFO: Make sure to build [mvn clean install] after 'commiting your changes'.\e[0m\n"
        exit 1
    fi
else
    echo -e "\n\e[92mINFO: User has passed unit test policy[branch - $target_branch_name], hence the user can proceed further.\e[0m\n"
    exit 0
fi
